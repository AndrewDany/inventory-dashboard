<?php
return [
    'host'     => 'localhost',
    'database' => 'samdjnsx_inventory_db',
    'username' => 'samdjnsx_invapp',
    'password' => 'Passgamegh1234%#!',
];